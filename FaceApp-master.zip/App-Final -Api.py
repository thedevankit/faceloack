from io import BytesIO
import re, time, base64
from base64 import decodestring
import cv2
import math
from sklearn import neighbors
import os
import os.path
import pickle
import json
from PIL import Image, ImageDraw
import face_recognition
from face_recognition.face_recognition_cli import image_files_in_folder
from flask import Flask, jsonify, request, redirect, render_template
import FaceKnn_Training as ft
from shutil import copyfile

app = Flask(__name__)
APP_ROOT = os.path.dirname(os.path.abspath(__file__))

face_cascade = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')
image_path = 'D:/FaceDetectionWebApp/User-Uploaded-Images'



@app.route('/upload_image', methods=['GET', 'POST'])
def upload_image():
    # Check if a valid image file was uploaded
    if request.method == 'POST':
        if 'file' not in request.files:
            return redirect(request.url)

        file = request.files['file']

        if file.filename == '':
            return redirect(request.url)

        if file and allowed_file(file.filename):
            # The image file seems valid! Detect faces and return the result.
            Imgresult = detect_faces_in_image(request.url)
            print(str(Imgresult))
            return jsonify({"status":"success", "result" : Imgresult})

    # If no valid image file was uploaded, show the file upload form:
    return '''
    <!doctype html>
    <title>Is this a picture of Obama?</title>
    <h1>Upload a picture and see if it's a picture of Obama!</h1>
    <form method="POST" enctype="multipart/form-data">
      <input type="file" name="file">
      <input type="submit" value="Upload">
    </form>
    '''

@app.route("/registruser", methods=['POST'])
def registruser():
    imgstring = request.form['file']
    userName = str(request.form['userID'])
    if not userName.strip():
        return jsonify({'fail':'Name not found.'})

    else:
        getI420FromBase64(imgstring)

        # Image Acquisition
        image = face_recognition.load_image_file("temp-img/webcam.jpg")
        face_bounding_boxes = face_recognition.face_locations(image)
        if len(face_bounding_boxes) > 1:
            return jsonify({'fail':'Multiple faces found.'})
        else:
            img = cv2.imread("temp-img/webcam.jpg")
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            faces = face_cascade.detectMultiScale(gray, 1.3, 5)

            for (x,y,w,h) in faces:
                cv2.rectangle(img,(x,y),(x+w,y+h),(255,0,0),2)
                roi_gray = gray[y:y+h, x:x+w]
                roi_color = img[y:y+h, x:x+w]

                #unique Id generated for folder and image names
                uniqueId = time.time()
                dirName = userName+"-Id-" + str(uniqueId)
                os.mkdir("Model-Training/train/"+dirName)
                os.rename("temp-img/webcam.jpg", "Model-Training/train/"+dirName+"/webcam.jpg")

                #Applying Gaussian blr
                gaussian = cv2.GaussianBlur(roi_gray, (15,15), 0) 
                #Applying bilateral blr
                bilateral = cv2.bilateralFilter(roi_color, 9, 80, 80) 
                #Applying EqualizeHist blr
                median = cv2.medianBlur(roi_color, 7) 
                # Save crop grayscale image to disk
                cv2.imwrite("Model-Training/train/"+ dirName +"/"+ str(uniqueId) + ".jpg", roi_gray)
                cv2.imwrite("Model-Training/train/" + dirName +"/"+ str(uniqueId+1) + ".jpg", roi_color)
                cv2.imwrite("Model-Training/train/" + dirName +"/"+ str(uniqueId+2) + ".jpg", median)
                cv2.imwrite("Model-Training/train/" + dirName +"/"+ str(uniqueId+3) + ".jpg", gaussian)
                cv2.imwrite("Model-Training/train/" + dirName +"/"+ str(uniqueId+4) + ".jpg", bilateral)

                ft.train("Model-Training/train", model_save_path="trained_knn_model.clf", n_neighbors=2)
                return jsonify({'success':'Training complete. Please go to login'})
            return jsonify({'fail':'Name not found.'})


# Post method for upload image
@app.route("/upload", methods=['POST'])
def upload():
    imgstring = request.form['file']
    
    # Call function to convert Base64 String to Image
    getI420FromBase64(imgstring)

    # Reading image 
    image = face_recognition.load_image_file("temp-img/webcam.jpg")
    face_bounding_boxes = face_recognition.face_locations(image)
    if len(face_bounding_boxes) > 1:
        return jsonify({'fail':'Multiple faces found.'})
    else:
        img = cv2.imread("temp-img/webcam.jpg")
        # To find face in image and convert it to grayscale.
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        faces = face_cascade.detectMultiScale(gray, 1.3, 5)
        for (x,y,w,h) in faces:
            cv2.rectangle(img,(x,y),(x+w,y+h),(255,0,0),2)
            roi_gray = gray[y:y+h, x:x+w]
            t = time.time()
            
            # Save crop grayscale image to disk
            isImgAvailable = cv2.imwrite( "temp-img/"+str(t) + ".jpg", roi_gray)
            if ( isImgAvailable):
                Imgresult = detect_faces_in_image("temp-img/"+str(t) + ".jpg")
                print(str(Imgresult))
                return jsonify({"status":"success", "result" : Imgresult})
        return jsonify({'fail':'Face not found'})



# Function to convert base64 string to image
def getI420FromBase64(codec):
    base64_data = re.sub('^data:image/.+;base64,', '', codec)
    byte_data = base64.b64decode(base64_data)
    image_data = BytesIO(byte_data)
    imggeSave = Image.open(image_data)
    imggeSave.save('temp-img/webcam.jpg', "JPEG")

def predict(X_img_path, knn_clf=None, model_path=None, distance_threshold=0.4):

    if knn_clf is None and model_path is None:
        raise Exception("Must supply knn classifier either thourgh knn_clf or model_path")

    # Load a trained KNN model (if one was passed in)
    if knn_clf is None:
        with open(model_path, 'rb') as f:
            knn_clf = pickle.load(f)

    # Load image file and find face locations
    # X_img = face_recognition.load_image_file(X_img_path)
    X_face_locations = face_recognition.face_locations(X_img_path)

    # If no faces are found in the image, return an empty result.
    if len(X_face_locations) == 0:
        return []

    # Find encodings for faces in the test iamge
    faces_encodings = face_recognition.face_encodings(X_img_path, known_face_locations=X_face_locations,num_jitters=2)

    # Use the KNN model to find the best matches for the test face
    closest_distances = knn_clf.kneighbors(faces_encodings, n_neighbors=1)
    are_matches = [closest_distances[0][i][0] <= distance_threshold for i in range(len(X_face_locations))]

    # Predict classes and remove classifications that aren't within the threshold
    return [(pred, loc) if rec else ("unknown", loc) for pred, loc, rec in zip(knn_clf.predict(faces_encodings), X_face_locations, are_matches)]


def detect_faces_in_image(file_stream):
    # Load the uploaded image file

    print("File Uploaded \n" + file_stream + "\n\n")
    img = face_recognition.load_image_file(file_stream)

    # Model passed to the function 
    predictions = predict(img, model_path="trained_knn_model.clf")

    result = []
    for name, (top, right, bottom, left) in predictions:
        result.append(name.split('-I', 1)[0])
      
    return result


if __name__ == "__main__":
    # uncomment for accessing in network
    # app.run(host='192.168.4.58',port=4555, debug=True,ssl_context='adhoc')

    # for local server
    app.run(port=4555, debug=True)
    
